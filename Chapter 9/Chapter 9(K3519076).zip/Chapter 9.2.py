n = 4
for i in range(n):
    bintang = ("* " * (i+(i+1)))
    print(bintang.center(20))