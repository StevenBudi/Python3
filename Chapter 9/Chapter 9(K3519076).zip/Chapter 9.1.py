def ubahHuruf(teks, a, b):
    print(teks.replace(a, b))

ubahHuruf("MATEMATIKA", "T", "S")

    

